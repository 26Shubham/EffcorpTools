import pandas as pd
import numpy as np
import os
import glob

from openpyxl import load_workbook
from shutil import copyfile
import datetime
import warnings
import re
from difflib import SequenceMatcher, get_close_matches

warnings.filterwarnings('ignore')


def flatten_dict(dic):
    """
    This is  avery useful function to flatten any dictionary which consists of a nested list of a nested dictionary

    This function taken only 1 parameter ,

    The parameter must be a dictionary

    This function has a depndent function i.e expand_list

    Both these functions always to be used simultaneously as they are compimentary to each other


    """

    import pandas as pd
    import json
    import warnings
    from openpyxl import load_workbook
    import os

    warnings.filterwarnings('ignore')

    df2 = pd.DataFrame()

    key_list = list(dic.keys())
    flat_dict = dict()

    for i in key_list:
        dict_whole = {i: dic[i]}
        dict_value = dic[i]

        if isinstance(dict_value, dict):
            flat_dict.update(dict_value)

        elif isinstance(dict_value, list):

            if len(dict_value) == 1:
                a = dict_value[0]
                b = flatten_dict(a)
                flat_dict.update(b)
            elif len(dict_value) == 0:
                pass

            else:
                dicdf = expand_list(dict_value)
                flat_dict.update(dicdf)

        else:
            flat_dict.update(dict_whole)

    data_list = list(flat_dict.items())

    df = pd.DataFrame(data_list)
    df1 = df.T
    df1.columns = df1.loc[0]
    df1 = df1.drop(0)
    df1 = df1.reset_index(drop=True)
    return (flat_dict)


def expand_list(list_dic):
    """
    This is  avery useful function to flatten any list which consists of a nested list or even a nested dictionary

    This function taken only 1 parameter ,

    The parameter must be of type list

    This function has a depndent function i.e flatten_dict

    Both these functions always to be used simultaneously as they are compimentary to each other

    """

    import pandas as pd
    import json
    import warnings
    from openpyxl import load_workbook
    import os

    warnings.filterwarnings('ignore')

    df2 = pd.DataFrame()

    if len(list_dic) == 1:
        a = list_dic[0]
        b = flatten_dict(a)
        conv_dict = b
    else:

        for i in list_dic:
            if isinstance(i, dict):

                flat_dictl = flatten_dict(i)

                try:
                    df1 = pd.DataFrame(flat_dictl)
                except:
                    df = pd.DataFrame(list(flat_dictl.items()))
                    df1 = df.T
                    df1.columns = df1.loc[0]
                    df1 = df1.drop(0)
                    df1 = df1.reset_index(drop=True)

                df2 = df2.append(df1)

            elif isinstance(i, list):
                a = expand_list(i)
                df2 = a

            else:
                dict_whole = {i: list_dic[i]}
                df = pd.DataFrame(list(dict_whole.items()))
                df1 = df.T
                df1.columns = df1.loc[0]
                df1 = df1.drop(0)
                df1 = df1.reset_index(drop=True)

                df2 = df2.append(df1)

        conv_dict = df2.to_dict(orient="list")

    return (conv_dict)



def merge_gstr2b_excel(folder):
    """

    This function is for merging all the GSTR2B excel file as downloaded from the GST Portal.

    This function takes only one parameter i.e the folder pth in which these excel files are stored.

    Do not keep any other excel file. ALso, do no keep the GSTR2B summary file in this folder.


    """

    import pandas as pd
    import glob
    import os
    from UliPlot.XLSX import auto_adjust_xlsx_column_width

    filenames = glob.glob(folder + "/*.xlsx")

    df_master = pd.DataFrame()

    df_b2b = pd.DataFrame()

    path = os.path.join(folder, "Combined_GSTR2B_All.xlsx")

    writer = pd.ExcelWriter(path, engine='xlsxwriter', engine_kwargs={'options': {'strings_to_numbers': True}})

    for file in filenames:

        file_name = file.split("\\")[-1]
        print(f"Working on B2B data...for file {file_name}")

        try:

            df = pd.read_excel(file, sheet_name="B2B")
            df = df.rename({'Goods and Services Tax  - GSTR-2B': 'GSTIN_of_Supplier',
                            'Unnamed: 1': 'Trade_Name_of_Supplier',
                            'Unnamed: 2': 'Final_Invoice_CNDN_No',
                            'Unnamed: 3': 'Final_Inv_CNDN_Type',
                            'Unnamed: 4': 'Final_Invoice_CNDN_Date',
                            'Unnamed: 5': 'Invoice_CNDN_Value',
                            'Unnamed: 6': 'Place_Of_Supply',
                            'Unnamed: 7': 'Supply_Attract_Reverse_Charge',
                            'Unnamed: 8': 'Tax_Rate',
                            'Unnamed: 9': 'Taxable_Value',
                            'Unnamed: 10': 'IGST_Amount',
                            'Unnamed: 11': 'CGST_Amount',
                            'Unnamed: 12': 'SGST_Amount',
                            'Unnamed: 13': 'Cess_Amount',
                            'Unnamed: 14': 'Supplier_Filing_Period',
                            'Unnamed: 15': 'Supplier_Filing_Date',
                            'Unnamed: 16': 'ITC_Available',
                            'Unnamed: 17': 'Reason',
                            'Unnamed: 18': 'Applicable_Percent_TaxRate',
                            'Unnamed: 19': 'Source_Type',
                            'Unnamed: 20': 'IRN',
                            'Unnamed: 21': 'IRN_Generate_Date'}, axis=1)

            df = df.drop([0, 1, 2, 3, 4])
            df['GSTR2B_Table'] = "B2B"
            df['File_Name'] = file
            df_b2b = df_b2b.append(df)
        except:
            pass

    df_b2ba = pd.DataFrame()

    for file in filenames:

        file_name = file.split("\\")[-1]
        print(f"Working on B2BA data...for file {file_name}")

        try:

            df = pd.read_excel(file, sheet_name="B2BA")
            df = df.rename({'Goods and Services Tax  - GSTR-2B': 'Initial_Inv_CNDN_Num',
                            'Unnamed: 1': 'Initial_Inv_CNDN_Date',
                            'Unnamed: 2': 'GSTIN_of_Supplier',
                            'Unnamed: 3': 'Trade_Name_of_Supplier',
                            'Unnamed: 4': 'Final_Invoice_CNDN_No',
                            'Unnamed: 5': 'Final_Inv_CNDN_Type',
                            'Unnamed: 6': 'Final_Invoice_CNDN_Date',
                            'Unnamed: 7': 'Invoice_CNDN_Value',
                            'Unnamed: 8': 'Place_Of_Supply',
                            'Unnamed: 9': 'Supply_Attract_Reverse_Charge',
                            'Unnamed: 10': 'Tax_Rate',
                            'Unnamed: 11': 'Taxable_Value',
                            'Unnamed: 12': 'IGST_Amount',
                            'Unnamed: 13': 'CGST_Amount',
                            'Unnamed: 14': 'SGST_Amount',
                            'Unnamed: 15': 'Cess_Amount',
                            'Unnamed: 16': 'Supplier_Filing_Period',
                            'Unnamed: 17': 'Supplier_Filing_Date',
                            'Unnamed: 18': 'ITC_Available',
                            'Unnamed: 19': 'Reason',
                            'Unnamed: 20': 'Applicable_Percent_TaxRate'}, axis=1)
            df = df.drop([0, 1, 2, 3, 4, 5])
            df['GSTR2B_Table'] = "B2BA"
            df['File_name'] = file
            df_b2ba = df_b2ba.append(df)
        except:
            pass

    df_b2bcd = pd.DataFrame()

    for file in filenames:

        file_name = file.split("\\")[-1]
        print(f"Working on CDNR data...for file {file_name}")

        try:

            df = pd.read_excel(file, sheet_name="B2B-CDNR")
            df = df.rename({'Goods and Services Tax  - GSTR-2B': 'GSTIN_of_Supplier',
                            'Unnamed: 1': 'Trade_Name_of_Supplier',
                            'Unnamed: 2': 'Final_Invoice_CNDN_No',
                            'Unnamed: 3': 'Final_Inv_CNDN_Type',
                            'Unnamed: 4': 'Note_Supply_Type',
                            'Unnamed: 5': 'Final_Invoice_CNDN_Date',
                            'Unnamed: 6': 'Invoice_CNDN_Value',
                            'Unnamed: 7': 'Place_Of_Supply',
                            'Unnamed: 8': 'Supply_Attract_Reverse_Charge',
                            'Unnamed: 9': 'Tax_Rate',
                            'Unnamed: 10': 'Taxable_Value',
                            'Unnamed: 11': 'IGST_Amount',
                            'Unnamed: 12': 'CGST_Amount',
                            'Unnamed: 13': 'SGST_Amount',
                            'Unnamed: 14': 'Cess_Amount',
                            'Unnamed: 15': 'Supplier_Filing_Period',
                            'Unnamed: 16': 'Supplier_Filing_Date',
                            'Unnamed: 17': 'ITC_Available',
                            'Unnamed: 18': 'Reason',
                            'Unnamed: 19': 'Applicable_Percent_TaxRate',
                            'Unnamed: 20': 'Source_Type',
                            'Unnamed: 21': 'IRN',
                            'Unnamed: 22': 'IRN_Generate_Date'}, axis=1)
            df = df.drop([0, 1, 2, 3, 4])
            df['GSTR2B_Table'] = "B2B-CDNR"
            df['File_name'] = file
            df_b2bcd = df_b2bcd.append(df)
        except:
            pass

    df_b2bcdnra = pd.DataFrame()

    for file in filenames:

        file_name = file.split("\\")[-1]
        print(f"Working on CDNRA data...for file {file_name}")

        try:

            df = pd.read_excel(file, sheet_name="B2B-CDNRA")
            df = df.rename({'Goods and Services Tax  - GSTR-2B': 'Initial_Inv_CNDN_Type',
                            'Unnamed: 1': 'Initial_Inv_CNDN_No',
                            'Unnamed: 2': 'Initial_Inv_CNDN_Date',
                            'Unnamed: 3': 'GSTIN_of_Supplier',
                            'Unnamed: 4': 'Trade_Name_of_Supplier',
                            'Unnamed: 5': 'Final_Invoice_CNDN_No',
                            'Unnamed: 6': 'Final_Inv_CNDN_Type',
                            'Unnamed: 7': 'Note_Supply_Type',
                            'Unnamed: 8': 'Final_Invoice_CNDN_Date',
                            'Unnamed: 9': 'Invoice_CNDN_Value',
                            'Unnamed: 10': 'Place_Of_Supply',
                            'Unnamed: 11': 'Supply_Attract_Reverse_Charge',
                            'Unnamed: 12': 'Tax_Rate',
                            'Unnamed: 13': 'Taxable_Value',
                            'Unnamed: 14': 'IGST_Amount',
                            'Unnamed: 15': 'CGST_Amount',
                            'Unnamed: 16': 'SGST_Amount',
                            'Unnamed: 17': 'Cess_Amount',
                            'Unnamed: 18': 'Supplier_Filing_Period',
                            'Unnamed: 19': 'Supplier_Filing_Date',
                            'Unnamed: 20': 'ITC_Available',
                            'Unnamed: 21': 'Reason',
                            'Unnamed: 22': 'Applicable_Percent_TaxRate'}, axis=1)
            df = df.drop([0, 1, 2, 3, 4, 5])
            df['GSTR2B_Table'] = "B2B-CDNRA"
            df['File_name'] = file
            df_b2bcdnra = df_b2bcdnra.append(df)

        except:
            pass

    df_isd = pd.DataFrame()

    for file in filenames:

        file_name = file.split("\\")[-1]
        print(f"Working on ISD data...for file {file_name}")

        try:

            df = pd.read_excel(file, sheet_name="ISD")
            df = df.rename({'Goods and Services Tax  - GSTR-2B': 'GSTIN_of_Supplier',
                            'Unnamed: 1': 'Trade_Name_of_Supplier',
                            'Unnamed: 2': 'Final_Inv_CNDN_Type',
                            'Unnamed: 3': 'Final_Invoice_CNDN_No',
                            'Unnamed: 4': 'Final_Invoice_CNDN_Date',
                            'Unnamed: 5': 'Initial_Inv_CNDN_No',
                            'Unnamed: 6': 'Initial_Inv_CNDN_Date',
                            'Unnamed: 7': 'IGST_Amount',
                            'Unnamed: 8': 'CGST_Amount',
                            'Unnamed: 9': 'SGST_Amount',
                            'Unnamed: 10': 'Cess_Amount',
                            'Unnamed: 11': 'Supplier_Filing_Period',
                            'Unnamed: 12': 'Supplier_Filing_Date',
                            'Unnamed: 13': 'ITC_Available'}, axis=1)
            df = df.drop([0, 1, 2, 3, 4])
            df['GSTR2B_Table'] = "ISD"
            df['File_name'] = file
            df_isd = df_isd.append(df)
        except:
            pass

    df_impg = pd.DataFrame()

    for file in filenames:

        file_name = file.split("\\")[-1]
        print(f"Working on IMPORT data...for file {file_name}")

        try:

            df = pd.read_excel(file, sheet_name="IMPG")
            df = df.rename({'Goods and Services Tax  - GSTR-2B': 'IceGate_Ref_Date',
                            'Unnamed: 1': 'Port_Code',
                            'Unnamed: 2': 'Bill_Of_Entry_No',
                            'Unnamed: 3': 'Record_Date',
                            'Unnamed: 4': 'Taxable_Value',
                            'Unnamed: 5': 'IGST_Amount',
                            'Unnamed: 6': 'Cess_Amount',
                            'Unnamed: 7': 'Amended_Y_N'}, axis=1)
            df = df.drop([0, 1, 2, 3, 4])
            df['File_name'] = file
            df['GSTR2B_Table'] = "IMPG"
            df_impg = df_impg.append(df)
        except:
            pass

    print("Combining all the files...")

    df_master = pd.concat([df_b2b, df_b2ba, df_b2bcd, df_b2bcdnra, df_isd, df_impg])

    df_master.to_excel(writer, sheet_name="All_Combined", index=False)
    auto_adjust_xlsx_column_width(df_master, writer, sheet_name="All_Combined", margin=10)

    df_b2ba.to_excel(writer, sheet_name="B2BA", index=False)
    auto_adjust_xlsx_column_width(df_b2ba, writer, sheet_name="B2BA", margin=10)

    df_b2b.to_excel(writer, sheet_name="B2B", index=False)
    auto_adjust_xlsx_column_width(df_b2b, writer, sheet_name="B2B", margin=10)

    df_impg.to_excel(writer, sheet_name="IMPG", index=False)
    auto_adjust_xlsx_column_width(df_b2bcd, writer, sheet_name="IMPG", margin=10)

    df_isd.to_excel(writer, sheet_name="ISD", index=False)
    auto_adjust_xlsx_column_width(df_b2bcd, writer, sheet_name="ISD", margin=10)

    df_b2bcdnra.to_excel(writer, sheet_name="B2B-CDNRA", index=False)
    auto_adjust_xlsx_column_width(df_b2bcd, writer, sheet_name="B2B-CDNRA", margin=10)

    df_b2bcd.to_excel(writer, sheet_name="B2B-CDNR", index=False)
    auto_adjust_xlsx_column_width(df_b2bcd, writer, sheet_name="B2B-CDNR", margin=10)

    writer.save()

    print(f"All excel files of GSTR2B has been Combined. Combined files stored in {path}")


def rename_2b_columns(dataframe):
    """

    This is a support function for the gstr2B to Excel conversion


    """

    dataframe.rename(columns={"dt": "Final_Invoice_CNDN_Date",
                              "val": "Invoice_CNDN_Value",
                              "rev": "Supply_Attract_Reverse_Charge",
                              "itcavl": "ITC_Available",
                              "diffprcnt": "Applicable_Percent_TaxRate",
                              "pos": "Place_Of_Supply",
                              "typ": "Final_Inv_CNDN_Type",
                              "inum": "Final_Invoice_CNDN_No",
                              "rsn": "Reason",
                              "sgst": "SGST_Amount",
                              "rt": "Tax_Rate",
                              "num": "Check_num",
                              "txval": "Taxable_Value",
                              "cgst": "CGST_Amount",
                              "cess": "Cess_Amount",
                              "trdnm": "Trade_Name_of_Supplier",
                              "supfildt": "Supplier_Filing_Date",
                              "supprd": "Supplier_Filing_Period",
                              "ctin": "GSTIN_of_Supplier",
                              "igst": "IGST_Amount",
                              "irn": "IRN",
                              "irngendate": "IRN_Generate_Date",
                              "srctyp": "Source_Type",
                              "GSTR2B-Table": "GSTR2B-Table",
                              "rtnprd": "GSTR2B_Period",
                              "gstin": "Recipient_GSTIN",
                              "Json File Name": "JSON_Source_File",
                              "File_Name": "Source_Excel_File",
                              "oinum": "Initial_Inv_CNDN_No",
                              "oidt": "Initial_Inv_CNDN_Date",
                              "ntnum": "Final_Invoice_CNDN_No",
                              "suptyp": "Note_Supply_Type",
                              "ontdt": "Initial_Inv_CNDN_Date",
                              "onttyp": "Initial_Inv_CNDN_Type",
                              "ontnum": "Initial_Inv_CNDN_No",
                              "docnum": "Final_Invoice_CNDN_No",
                              "itcelg": "ITC_Available",
                              "doctyp": "Final_Inv_CNDN_Type",
                              "docdt": "Final_Invoice_CNDN_Date",
                              "oinvnum": "Initial_Inv_CNDN_No",
                              "oinvdt": "Initial_Inv_CNDN_Date",
                              "boedt": "Bill_Of_Entry_Date",
                              "isamd": "Amended_Y_N",
                              "recdt": "Record_Date",
                              "refdt": "IceGate_Ref_Date",
                              "boenum": "Bill_Of_Entry_No",
                              "portcode": "Port_Code"}, inplace=True)


def gstr2bjson_to_excel(filepath):
    """
    This is a very easy to use funcion to extract the json data of GSTR2b into an excel file.
    This function takes only one argument i.e a completepath to the json file upto extension
    Simply pass the complete path and run.
    Table wise data will be populated in the Excel sheet
    """

    import pandas as pd
    import json
    import warnings
    from openpyxl import load_workbook
    import os

    warnings.filterwarnings('ignore')

    try:
        from io import BytesIO as IO
    except ImportError:
        from io import StringIO as IO

    excel_file = IO()

    writer = pd.ExcelWriter(excel_file, engine='xlsxwriter')

    df_impg = pd.DataFrame()
    df_isd = pd.DataFrame()
    df_cdnr = pd.DataFrame()
    df_cdnra = pd.DataFrame()
    df_b2b = pd.DataFrame()
    df_b2ba = pd.DataFrame()

    with open(filepath) as json_file:
        data = json.load(json_file)

        main_data = data["data"]['docdata']

        return_period = data["data"]["rtnprd"]
        rec_gstin = data["data"]["gstin"]

        for i in main_data.keys():

            if i == "b2b":

                b2b_data = main_data[i]
                dic_b2b = expand_list(b2b_data)

                try:

                    df_b2b = pd.DataFrame(dic_b2b)
                except ValueError:
                    df_b2b = pd.DataFrame(dic_b2b, index=[0])

                df_b2b["GSTR2B_Table"] = i
                df_b2b["rtnprd"] = return_period
                df_b2b["gstin"] = rec_gstin
                df_b2b["Json File Name"] = filepath

                df_b2b.to_excel(writer, sheet_name=str(i + '_data'), index=False)

                rename_2b_columns(df_b2b)



            elif i == "b2ba":

                b2ba_data = main_data[i]
                dic_b2ba = expand_list(b2ba_data)

                try:
                    df_b2ba = pd.DataFrame(dic_b2ba)
                except ValueError:
                    df_b2ba = pd.DataFrame(dic_b2ba, index=[0])

                df_b2ba["GSTR2B_Table"] = i
                df_b2ba["rtnprd"] = return_period
                df_b2ba["gstin"] = rec_gstin
                df_b2ba["Json File Name"] = filepath

                df_b2ba.to_excel(writer, sheet_name=str(i + '_data'), index=False)

                rename_2b_columns(df_b2ba)





            elif i == "cdnr":

                cdnr_data = main_data[i]
                dic_cdnr = expand_list(cdnr_data)

                try:
                    df_cdnr = pd.DataFrame(dic_cdnr)
                except ValueError:
                    df_cdnr = pd.DataFrame(dic_cdnr, index=[0])

                df_cdnr["GSTR2B_Table"] = i
                df_cdnr["rtnprd"] = return_period
                df_cdnr["gstin"] = rec_gstin
                df_cdnr["Json File Name"] = filepath

                df_cdnr.to_excel(writer, sheet_name=str(i + '_data'), index=False)

                rename_2b_columns(df_cdnr)





            elif i == "cdnra":

                cdnra_data = main_data[i]
                dic_cdnra = expand_list(cdnra_data)

                try:
                    df_cdnra = pd.DataFrame(dic_cdnra)
                except ValueError:
                    df_cdnra = pd.DataFrame(dic_cdnra, index=[0])

                df_cdnra["GSTR2B_Table"] = i
                df_cdnra["rtnprd"] = return_period
                df_cdnra["gstin"] = rec_gstin
                df_cdnra["Json File Name"] = filepath

                df_cdnra.to_excel(writer, sheet_name=str(i + '_data'), index=False)

                rename_2b_columns(df_cdnra)



            elif i == "isd":

                isd_data = main_data[i]
                dic_isd = expand_list(isd_data)

                try:
                    df_isd = pd.DataFrame(dic_isd)
                except ValueError:
                    df_isd = pd.DataFrame(dic_isd, index=[0])

                df_isd["GSTR2B_Table"] = i
                df_isd["rtnprd"] = return_period
                df_isd["gstin"] = rec_gstin
                df_isd["Json File Name"] = filepath

                df_isd.to_excel(writer, sheet_name=str(i + '_data'), index=False)

                rename_2b_columns(df_isd)



            elif i == "impg":

                impg_data = main_data[i]
                dic_impg = expand_list(impg_data)

                try:
                    df_impg = pd.DataFrame(dic_impg)
                except ValueError:
                    df_impg = pd.DataFrame(dic_impg, index=[0])

                df_impg["GSTR2B_Table"] = i
                df_impg["rtnprd"] = return_period
                df_impg["gstin"] = rec_gstin
                df_impg["Json File Name"] = filepath

                df_impg.to_excel(writer, sheet_name=str(i + '_data'), index=False)

                rename_2b_columns(df_impg)


            else:

                pass

    combined_2b = pd.concat([df_b2b, df_b2ba, df_cdnr, df_cdnra, df_isd, df_impg])

    combined_2b.to_excel(writer, sheet_name="effcorp_all_combined", index=False)

    writer.save()
    writer.close()

    return (excel_file)