import pandas as pd
import glob
import os
import warnings

def gstr2a_merge(files):

    warnings.filterwarnings('ignore')

    cum_size = 0

    for file in files:
        size = os.path.getsize(file)

        cum_size = cum_size + size

        if size > 31457280:
            print("Please upload a smaller file size. Maximum limit is 30 mb.")

        elif cum_size > 314572800:
            print("Combined File size for all the file is more than 300 mb. Please use smaller files")
            break
        else:
            pass

    # A. iterate through each file to append it one below the other

    print(f"The files that will be combined are")

    df_all_b2b = pd.DataFrame()

    df_all_b2ba = pd.DataFrame()

    df_all_cdnr = pd.DataFrame()

    df_all_cdnra = pd.DataFrame()

    for file in files:
        file_name = file.split("\\")[-1]

        df_b2b = pd.read_excel(file, sheet_name=1)

        df_b2b = df_b2b.drop([0, 1, 2, 3, 4], axis=0)

        df_b2b = df_b2b.dropna(how='all')

        df_b2b['File_name'] = file

        df_all_b2b = df_all_b2b.append(df_b2b)

        print(f"Working on B2B sheet of {file_name}")

        df_b2ba = pd.read_excel(file, sheet_name=2)

        df_b2ba = df_b2ba.drop([0, 1, 2, 3, 4, 5], axis=0)

        df_b2ba = df_b2ba.dropna(how='all')

        df_b2ba['File_name'] = file

        df_all_b2ba = df_all_b2ba.append(df_b2ba)

        print(f"Working on B2BA sheet of {file_name}")

        df_cdnr = pd.read_excel(file, sheet_name=3)

        df_cdnr = df_cdnr.drop([0, 1, 2, 3, 4], axis=0)

        df_cdnr = df_cdnr.dropna(how='all')

        df_cdnr['File_name'] = file

        df_all_cdnr = df_all_cdnr.append(df_cdnr)

        print(f"Working on CDNR sheet of {file_name}")

        df_cdnra = pd.read_excel(file, sheet_name=4)

        df_cdnra = df_cdnra.drop([0, 1, 2, 3, 4, 5], axis=0)

        df_cdnra = df_cdnra.dropna(how='all')

        df_cdnra['File_name'] = file

        df_all_cdnra = df_all_cdnra.append(df_cdnra)

        print(f"Working on CDNRA sheet of {file_name}")

    # this is used for deleting all the rows which are totally blank

    df3 = df_all_b2b

    # this is used for renaming the names of the columns

    df3.rename(columns={'Goods and Services Tax  - GSTR 2A': 'GSTIN_of_Supplier'}, inplace=True)
    df3.rename(columns={'Unnamed: 1': 'Trade_Name_of_Supplier'}, inplace=True)
    df3.rename(columns={'Unnamed: 2': 'Final_Invoice_CNDN_No'}, inplace=True)
    df3.rename(columns={'Unnamed: 3': 'Final_Inv_CNDN_Type'}, inplace=True)
    df3.rename(columns={'Unnamed: 4': 'Final_Invoice_CNDN_Date'}, inplace=True)
    df3.rename(columns={'Unnamed: 5': 'Invoice_CNDN_Value'}, inplace=True)
    df3.rename(columns={'Unnamed: 6': 'Place_Of_Supply'}, inplace=True)
    df3.rename(columns={'Unnamed: 7': 'Supply_Attract_Reverse_Charge'}, inplace=True)
    df3.rename(columns={'Unnamed: 8': 'Tax_Rate'}, inplace=True)
    df3.rename(columns={'Unnamed: 9': 'Taxable_Value'}, inplace=True)
    df3.rename(columns={'Unnamed: 10': 'IGST_Amount'}, inplace=True)
    df3.rename(columns={'Unnamed: 11': 'CGST_Amount'}, inplace=True)
    df3.rename(columns={'Unnamed: 12': 'SGST_Amount'}, inplace=True)
    df3.rename(columns={'Unnamed: 13': 'Cess_Amount'}, inplace=True)
    df3.rename(columns={'Unnamed: 14': 'GSTR_1_5_Filing_Status'}, inplace=True)
    df3.rename(columns={'Unnamed: 15': 'Supplier_Filing_Date'}, inplace=True)
    df3.rename(columns={'Unnamed: 16': 'Supplier_Filing_Period'}, inplace=True)
    df3.rename(columns={'Unnamed: 17': 'GSTR_3B_Filing_Status'}, inplace=True)
    df3.rename(columns={'Unnamed: 18': 'Amendment_made_if_any'}, inplace=True)
    df3.rename(columns={'Unnamed: 19': 'Tax_Period_in_which_Amended'}, inplace=True)
    df3.rename(columns={'Unnamed: 20': 'Effective_date_of_cancellation'}, inplace=True)
    df3.rename(columns={'Unnamed: 21': 'Source_Type'}, inplace=True)
    df3.rename(columns={'Unnamed: 22': 'IRN'}, inplace=True)
    df3.rename(columns={'Unnamed: 23': 'IRN_Generate_Date'}, inplace=True)

    # here we will remove the rows, in which the invoice number has  a total
    filt = df3['Final_Invoice_CNDN_No'].str.contains('Total', na=False)
    df3 = df3[~filt]

    df3['Inv_CN_DN_Date_Text'] = df3['Final_Invoice_CNDN_Date'].str.replace("-", ".")
    df3['Total_Tax'] = df3['IGST_Amount'] + df3['CGST_Amount'] + df3['SGST_Amount']
    df3['Unique_ID'] = df3['GSTIN_of_Supplier'] + "/" + df3['Final_Invoice_CNDN_No'] + "/" + df3[
        'Inv_CN_DN_Date_Text']

    df3['GSTR2A_Table'] = ("B2B")

    df3['PAN_Number'] = df3["GSTIN_of_Supplier"].apply(lambda x: x[2:12:1])

    df3 = df3.replace(np.nan, "", regex=True)

    # this is used for deleting all the rows which are totally blank
    df4 = df_all_b2ba.dropna(how='all')

    # this is used for renaming the names of the columns

    df4.rename(
        columns={'                                      Goods and Services Tax - GSTR-2A': 'Initial_Inv_CNDN_No'},
        inplace=True)
    df4.rename(columns={'Unnamed: 1': 'Initial_Inv_CNDN_Date'}, inplace=True)
    df4.rename(columns={'Unnamed: 2': 'GSTIN_of_Supplier'}, inplace=True)
    df4.rename(columns={'Unnamed: 3': 'Trade_Name_of_Supplier'}, inplace=True)
    df4.rename(columns={'Unnamed: 4': 'Final_Inv_CNDN_Type'}, inplace=True)
    df4.rename(columns={'Unnamed: 5': 'Final_Invoice_CNDN_No'}, inplace=True)
    df4.rename(columns={'Unnamed: 6': 'Final_Invoice_CNDN_Date'}, inplace=True)
    df4.rename(columns={'Unnamed: 7': 'Invoice_CNDN_Value'}, inplace=True)
    df4.rename(columns={'Unnamed: 8': 'Place_Of_Supply'}, inplace=True)
    df4.rename(columns={'Unnamed: 9': 'Supply_Attract_Reverse_Charge'}, inplace=True)
    df4.rename(columns={'Unnamed: 10': 'Tax_Rate'}, inplace=True)
    df4.rename(columns={'Unnamed: 11': 'Taxable_Value'}, inplace=True)
    df4.rename(columns={'Unnamed: 12': 'IGST_Amount'}, inplace=True)
    df4.rename(columns={'Unnamed: 13': 'CGST_Amount'}, inplace=True)
    df4.rename(columns={'Unnamed: 14': 'SGST_Amount'}, inplace=True)
    df4.rename(columns={'Unnamed: 15': 'Cess_Amount'}, inplace=True)
    df4.rename(columns={'Unnamed: 16': 'GSTR_1_5_Filing_Status'}, inplace=True)
    df4.rename(columns={'Unnamed: 17': 'Supplier_Filing_Date'}, inplace=True)
    df4.rename(columns={'Unnamed: 18': 'Supplier_Filing_Period'}, inplace=True)
    df4.rename(columns={'Unnamed: 19': 'GSTR_3B_Filing_Status'}, inplace=True)
    df4.rename(columns={'Unnamed: 20': 'Effective_date_of_cancellation'}, inplace=True)
    df4.rename(columns={'Unnamed: 21': 'Amendment_made_if_any'}, inplace=True)
    df4.rename(columns={'Unnamed: 22': 'Original_tax_period_in_which_reported'}, inplace=True)

    # here we will remove the rows, in which the invoice number has  a total
    filt = df4['Final_Invoice_CNDN_No'].str.contains('Total', na=False)

    df4 = df4[~filt]

    df4['Inv_CN_DN_Date_Text'] = df4['Final_Invoice_CNDN_Date'].str.replace("-", ".")
    df4['Total_Tax'] = df4['IGST_Amount'] + df4['CGST_Amount'] + df4['SGST_Amount']
    df4['Unique_ID'] = df4['GSTIN_of_Supplier'] + "/" + df4['Final_Invoice_CNDN_No'] + "/" + df4[
        'Inv_CN_DN_Date_Text']
    #     df4["Inv_CN_DN_Date_Revised_Unique"] = df4['Inv_CN_DN_Date_Revised'].str.replace("-", ".")

    df4['GSTR2A_Table'] = ("B2BA")

    df4['PAN_Number'] = df4["GSTIN_of_Supplier"].apply(lambda x: x[2:12:1])

    df4 = df4.replace(np.nan, "", regex=True)

    # this is used for deleting all the rows which are totally blank
    df5 = df_all_cdnr.dropna(how='all')

    # this is used for renaming the names of the columns

    df5.rename(
        columns={'                                             Goods and Services Tax - GSTR-2A': 'GSTIN_of_Supplier'},
        inplace=True)
    df5.rename(columns={'Unnamed: 1': 'Trade_Name_of_Supplier'}, inplace=True)
    df5.rename(columns={'Unnamed: 2': 'Final_Note_Supply_Type'}, inplace=True)
    df5.rename(columns={'Unnamed: 3': 'Final_Invoice_CNDN_No'}, inplace=True)
    df5.rename(columns={'Unnamed: 4': 'Final_Inv_CNDN_Type'}, inplace=True)
    df5.rename(columns={'Unnamed: 5': 'Final_Invoice_CNDN_Date'}, inplace=True)
    df5.rename(columns={'Unnamed: 6': 'Invoice_CNDN_Value'}, inplace=True)
    df5.rename(columns={'Unnamed: 7': 'Place_Of_Supply'}, inplace=True)
    df5.rename(columns={'Unnamed: 8': 'Supply_Attract_Reverse_Charge'}, inplace=True)
    df5.rename(columns={'Unnamed: 9': 'Tax_Rate'}, inplace=True)
    df5.rename(columns={'Unnamed: 10': 'Taxable_Value'}, inplace=True)
    df5.rename(columns={'Unnamed: 11': 'IGST_Amount'}, inplace=True)
    df5.rename(columns={'Unnamed: 12': 'CGST_Amount'}, inplace=True)
    df5.rename(columns={'Unnamed: 13': 'SGST_Amount'}, inplace=True)
    df5.rename(columns={'Unnamed: 14': 'Cess_Amount'}, inplace=True)
    df5.rename(columns={'Unnamed: 15': 'GSTR_1_5_Filing_Status'}, inplace=True)
    df5.rename(columns={'Unnamed: 16': 'Supplier_Filing_Date'}, inplace=True)
    df5.rename(columns={'Unnamed: 17': 'Supplier_Filing_Period'}, inplace=True)
    df5.rename(columns={'Unnamed: 18': 'GSTR_3B_Filing_Status'}, inplace=True)
    df5.rename(columns={'Unnamed: 19': 'Amendment_made_if_any'}, inplace=True)
    df5.rename(columns={'Unnamed: 20': 'Tax_Period_in_which_Amended'}, inplace=True)
    df5.rename(columns={'Unnamed: 21': 'Effective_date_of_cancellation'}, inplace=True)
    df5.rename(columns={'Unnamed: 22': 'Source_Type'}, inplace=True)
    df5.rename(columns={'Unnamed: 23': 'IRN'}, inplace=True)
    df5.rename(columns={'Unnamed: 24': 'IRN_Generate_Date'}, inplace=True)

    # here we will remove the rows, in which the invoice number has  a total
    filt = df5['Final_Invoice_CNDN_No'].str.contains('Total', na=False)

    df5 = df5[~filt]

    df5['Inv_CN_DN_Date_Text'] = df5['Final_Invoice_CNDN_Date'].str.replace("-", ".")
    df5['Total_Tax'] = df5['IGST_Amount'] + df5['CGST_Amount'] + df5['SGST_Amount']
    df5['Unique_ID'] = df5['GSTIN_of_Supplier'] + "/" + df5['Final_Invoice_CNDN_No'] + "/" + df5[
        'Inv_CN_DN_Date_Text']

    df5['GSTR2A_Table'] = ("CDNR")

    df5['PAN_Number'] = df5["GSTIN_of_Supplier"].apply(lambda x: x[2:12:1])

    df5 = df5.replace(np.nan, "", regex=True)

    # this is used for deleting all the rows which are totally blank

    df6 = df_all_cdnra.dropna(how='all')

    # this is used for renaming the names of the columns

    df6.rename(columns={'                             Goods and Services Tax - GSTR2A': 'Initial_Note_Supply_Type'},
               inplace=True)
    df6.rename(columns={'Unnamed: 1': 'Initial_Inv_CNDN_No'}, inplace=True)
    df6.rename(columns={'Unnamed: 2': 'Initial_Inv_CNDN_Date'}, inplace=True)
    df6.rename(columns={'Unnamed: 3': 'GSTIN_of_Supplier'}, inplace=True)
    df6.rename(columns={'Unnamed: 4': 'Trade_Name_of_Supplier'}, inplace=True)
    df6.rename(columns={'Unnamed: 5': 'Final_Note_Supply_Type'}, inplace=True)
    df6.rename(columns={'Unnamed: 6': 'Final_Invoice_CNDN_No'}, inplace=True)
    df6.rename(columns={'Unnamed: 7': 'Final_Inv_CNDN_Type'}, inplace=True)
    df6.rename(columns={'Unnamed: 8': 'Final_Invoice_CNDN_Date'}, inplace=True)
    df6.rename(columns={'Unnamed: 9': 'Invoice_CNDN_Value'}, inplace=True)
    df6.rename(columns={'Unnamed: 10': 'Place_Of_Supply'}, inplace=True)
    df6.rename(columns={'Unnamed: 11': 'Supply_Attract_Reverse_Charge'}, inplace=True)
    df6.rename(columns={'Unnamed: 12': 'Tax_Rate'}, inplace=True)
    df6.rename(columns={'Unnamed: 13': 'Taxable_Value'}, inplace=True)
    df6.rename(columns={'Unnamed: 14': 'IGST_Amount'}, inplace=True)
    df6.rename(columns={'Unnamed: 15': 'CGST_Amount'}, inplace=True)
    df6.rename(columns={'Unnamed: 16': 'SGST_Amount'}, inplace=True)
    df6.rename(columns={'Unnamed: 17': 'Cess_Amount'}, inplace=True)
    df6.rename(columns={'Unnamed: 18': 'GSTR_1_5_Filing_Status'}, inplace=True)
    df6.rename(columns={'Unnamed: 19': 'Supplier_Filing_Date'}, inplace=True)
    df6.rename(columns={'Unnamed: 20': 'Supplier_Filing_Period'}, inplace=True)
    df6.rename(columns={'Unnamed: 21': 'GSTR_3B_Filing_Status'}, inplace=True)
    df6.rename(columns={'Unnamed: 22': 'Amendment_made_if_any'}, inplace=True)
    df6.rename(columns={'Unnamed: 23': 'Original_tax_period_in_which_reported'}, inplace=True)
    df6.rename(columns={'Unnamed: 24': 'Effective_date_of_cancellation'}, inplace=True)

    # here we will remove the rows, in which the invoice number has  a total
    filt = df6['Final_Invoice_CNDN_No'].str.contains('Total', na=False)

    df6 = df6[~filt]

    df6['Inv_CN_DN_Date_Text'] = df6['Final_Invoice_CNDN_Date'].str.replace("-", ".")
    df6['Total_Tax'] = df6['IGST_Amount'] + df6['CGST_Amount'] + df6['SGST_Amount']
    df6['Unique_ID'] = df6['GSTIN_of_Supplier'] + "/" + df6['Final_Invoice_CNDN_No'] + "/" + df6[
        'Inv_CN_DN_Date_Text']

    #     df6["Inv_CN_DN_Date_Revised_Unique"] = df6['Inv_CN_DN_Date_Revised'].str.replace("-", ".")

    df6['GSTR2A_Table'] = ("CDNRA")

    df6['PAN_Number'] = df6["GSTIN_of_Supplier"].apply(lambda x: x[2:12:1])

    df6 = df6.replace(np.nan, "", regex=True)

    # Making a combined sheet with all merged

    print("We are Combining B2B, B2BA, CDNR & CDNRA in 1 sheet...Please wait..!")

    df8 = df3.append(df4)

    df9 = df8.append(df5)

    df10 = df9.append(df6)

    df10['PAN_Number'] = df10["GSTIN_of_Supplier"].apply(lambda x: x[2:12:1])

    df10 = df10.replace(np.nan, "", regex=True)

    df10["Ultimate_Unique"] = df10["GSTR2A_Table"] + "/" + df10["Supply_Attract_Reverse_Charge"] + df10[
        "GSTR_1_5_Filing_Status"] + "/" + df10["Unique_ID"]

    # this concatanating for B2BA cases, does nt require to use np.where coz we have now recitifed and kept as Final& Jnitial

    df10["PAN_3_Way_Key"] = np.where(df10["GSTR2A_Table"] == "B2BA",
                                     df10["PAN_Number"] + "/" + df10["Final_Invoice_CNDN_No"] + "/"
                                     + df10["Inv_CN_DN_Date_Text"],
                                     df10["PAN_Number"] + "/" + df10["Final_Invoice_CNDN_No"]
                                     + "/" + df10["Inv_CN_DN_Date_Text"])

    df10["PAN_2_Way_Key_PAN_InvNo"] = np.where(df10["GSTR2A_Table"] == "B2BA",
                                               df10["PAN_Number"] + "/" + df10["Final_Invoice_CNDN_No"]
                                               , df10["PAN_Number"] + "/" + df10["Final_Invoice_CNDN_No"])

    df10["PAN_2_Way_Key_PAN_InvDt"] = np.where(df10["GSTR2A_Table"] == "B2BA",
                                               df10["PAN_Number"] + "/" + df10["Inv_CN_DN_Date_Text"]
                                               , df10["PAN_Number"] + "/" + df10["Inv_CN_DN_Date_Text"])

    # Still, this np.where is not deleted for future reference

    # maiking a sheet with person who did not file the GSTR 1

    df11 = df10[df10['GSTR_1_5_Filing_Status'] == "N"]

    df12 = df10[(df10['Supply_Attract_Reverse_Charge'] == "Y") & (df10['GSTR_1_5_Filing_Status'] == "Y")]

    df13 = df10[(df10['Supply_Attract_Reverse_Charge'] == "N") & (df10['GSTR_1_5_Filing_Status'] == "Y") & (
            df10['Total_Tax'] < 1)]

    df14 = df10[(df10['Supply_Attract_Reverse_Charge'] == "N") & (df10['GSTR_1_5_Filing_Status'] == "Y") & (
            df10['Total_Tax'] >= 1)]

    # saving the file with the name "Combined"

    #     extension = ".xlsx"
    #     filename = os.path.splitext(filepath)[0]
    #     pth = os.path.dirname(filepath)
    excel_file = IO()

    writer = pd.ExcelWriter(newfile, engine='xlsxwriter', engine_kwargs={'options': {'strings_to_numbers': True}})

    print("Please wait.. we are creating different sheets and finalizing the file.....")

    df3.to_excel(writer, sheet_name="B2B", index=False)

    df4.to_excel(writer, sheet_name="B2BA", index=False)

    df5.to_excel(writer, sheet_name="CDNR", index=False)

    df6.to_excel(writer, sheet_name="CDNRA", index=False)

    titles = list(df10.columns)

    titles[0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], \
    titles[10], titles[11], titles[12], titles[13], titles[14], titles[15], titles[16], titles[17], titles[18], titles[
        19], titles[20], titles[21], titles[22], titles[23], titles[24], titles[25], titles[26], titles[27], titles[28], \
    titles[29], titles[30], titles[31], titles[32], titles[33], titles[34], titles[35] = titles[24], titles[28], titles[
        0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], titles[
                                                                                             10], titles[11], titles[
                                                                                             12], titles[13], titles[
                                                                                             26], titles[25], titles[
                                                                                             21], titles[27], titles[
                                                                                             14], titles[15], titles[
                                                                                             16], titles[17], titles[
                                                                                             18], titles[19], titles[
                                                                                             20], titles[22], titles[
                                                                                             23], titles[29], titles[
                                                                                             30], titles[31], titles[
                                                                                             32], titles[33], titles[
                                                                                             34], titles[35]

    df10[titles].to_excel(writer, sheet_name="All_Combined", index=False)

    titles = list(df11.columns)

    titles[0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], \
    titles[10], titles[11], titles[12], titles[13], titles[14], titles[15], titles[16], titles[17], titles[18], titles[
        19], titles[20], titles[21], titles[22], titles[23], titles[24], titles[25], titles[26], titles[27], titles[28], \
    titles[29], titles[30], titles[31], titles[32], titles[33], titles[34], titles[35] = titles[24], titles[28], titles[
        0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], titles[
                                                                                             10], titles[11], titles[
                                                                                             12], titles[13], titles[
                                                                                             26], titles[25], titles[
                                                                                             21], titles[27], titles[
                                                                                             14], titles[15], titles[
                                                                                             16], titles[17], titles[
                                                                                             18], titles[19], titles[
                                                                                             20], titles[22], titles[
                                                                                             23], titles[29], titles[
                                                                                             30], titles[31], titles[
                                                                                             32], titles[33], titles[
                                                                                             34], titles[35]

    df11[titles].to_excel(writer, sheet_name="GSTR_1_Not Filed", index=False)

    titles = list(df12.columns)

    titles[0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], \
    titles[10], titles[11], titles[12], titles[13], titles[14], titles[15], titles[16], titles[17], titles[18], titles[
        19], titles[20], titles[21], titles[22], titles[23], titles[24], titles[25], titles[26], titles[27], titles[28], \
    titles[29], titles[30], titles[31], titles[32], titles[33], titles[34], titles[35] = titles[24], titles[28], titles[
        0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], titles[
                                                                                             10], titles[11], titles[
                                                                                             12], titles[13], titles[
                                                                                             26], titles[25], titles[
                                                                                             21], titles[27], titles[
                                                                                             14], titles[15], titles[
                                                                                             16], titles[17], titles[
                                                                                             18], titles[19], titles[
                                                                                             20], titles[22], titles[
                                                                                             23], titles[29], titles[
                                                                                             30], titles[31], titles[
                                                                                             32], titles[33], titles[
                                                                                             34], titles[35]

    df12[titles].to_excel(writer, sheet_name="GSTR_Filed_RCM_Yes", index=False)

    titles = list(df13.columns)

    titles[0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], \
    titles[10], titles[11], titles[12], titles[13], titles[14], titles[15], titles[16], titles[17], titles[18], titles[
        19], titles[20], titles[21], titles[22], titles[23], titles[24], titles[25], titles[26], titles[27], titles[28], \
    titles[29], titles[30], titles[31], titles[32], titles[33], titles[34], titles[35] = titles[24], titles[28], titles[
        0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], titles[
                                                                                             10], titles[11], titles[
                                                                                             12], titles[13], titles[
                                                                                             26], titles[25], titles[
                                                                                             21], titles[27], titles[
                                                                                             14], titles[15], titles[
                                                                                             16], titles[17], titles[
                                                                                             18], titles[19], titles[
                                                                                             20], titles[22], titles[
                                                                                             23], titles[29], titles[
                                                                                             30], titles[31], titles[
                                                                                             32], titles[33], titles[
                                                                                             34], titles[35]

    df13[titles].to_excel(writer, sheet_name="Tax_Zero_Cases", index=False)

    titles = list(df14.columns)

    titles[0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], \
    titles[10], titles[11], titles[12], titles[13], titles[14], titles[15], titles[16], titles[17], titles[18], titles[
        19], titles[20], titles[21], titles[22], titles[23], titles[24], titles[25], titles[26], titles[27], titles[28], \
    titles[29], titles[30], titles[31], titles[32], titles[33], titles[34], titles[35] = titles[24], titles[28], titles[
        0], titles[1], titles[2], titles[3], titles[4], titles[5], titles[6], titles[7], titles[8], titles[9], titles[
                                                                                             10], titles[11], titles[
                                                                                             12], titles[13], titles[
                                                                                             26], titles[25], titles[
                                                                                             21], titles[27], titles[
                                                                                             14], titles[15], titles[
                                                                                             16], titles[17], titles[
                                                                                             18], titles[19], titles[
                                                                                             20], titles[22], titles[
                                                                                             23], titles[29], titles[
                                                                                             30], titles[31], titles[
                                                                                             32], titles[33], titles[
                                                                                             34], titles[35]

    df14[titles].to_excel(writer, sheet_name="Working_Cases", index=False)

    writer.save()
    writer.close()

    print(f"All files have been combined and a single file named {newfile} has been created")

    return (excel_file)
