import pandas as pd
import json
import warnings
from openpyxl import load_workbook
import os
from .gstr2b import flatten_dict,expand_list


def rename_r1_columns(dataframe):
    """
    This is a support function for the gstr2B to Excel conversion
    """

    dataframe.rename(columns={"idt": "Final_Invoice_CNDN_Date",
                              "val": "Invoice_CNDN_Value",
                              "rchrg": "Supply_Attract_Reverse_Charge",
                              "itcavl": "ITC_Available",
                              "diffprcnt": "Applicable_Percent_TaxRate",
                              "pos": "Place_Of_Supply",
                              "inv_typ": "Final_Inv_CNDN_Type",
                              "inum": "Final_Invoice_CNDN_No",
                              "rsn": "Reason",
                              "samt": "SGST_Amount",
                              "rt": "Tax_Rate",
                              "num": "Check_num",
                              "txval": "Taxable_Value",
                              "camt": "CGST_Amount",
                              "csamt": "Cess_Amount",
                              "ctin": "GSTIN_of_Customer",
                              "iamt": "IGST_Amount",
                              "irn": "IRN",
                              "cfs": "Counter_Party_Filing_Status",
                              "cflag": "Counter_Party_Action",
                              "updby": "Uploaded_By",
                              "chksum": "Check_Sum",
                              "flag": "Tax_Payer_Action",
                              "irngendate": "IRN_Generate_Date",
                              "srctyp": "Source_Type",
                              "GSTR2B-Table": "GSTR2B-Table",
                              "rtnprd": "GSTR2B_Period",
                              "gstin": "Recipient_GSTIN",
                              "Json File Name": "JSON_Source_File",
                              "typ": "Final_Inv_CNDN_Type",
                              "sply_ty": "Supply_Type",
                              "nt_dt": "Final_Invoice_CNDN_Date",
                              "nt_num": "Final_Invoice_CNDN_No",
                              "d_flag": "d_flag",
                              "exp_typ": "Final_Inv_CNDN_Type",
                              "File_Name": "Source_Excel_File"}, inplace=True)


def gstr1json_to_excel(filepath):


    warnings.filterwarnings('ignore')


    try:
        from io import BytesIO as IO
    except ImportError:
        from io import StringIO as IO

    fullpath1 = IO()

    writer = pd.ExcelWriter(fullpath1, engine='xlsxwriter', options={'strings_to_formulas': True})

    fullpath1a = IO()

    writer1 = pd.ExcelWriter(fullpath1a, engine='xlsxwriter', options={'strings_to_formulas': True})

    df1 = pd.DataFrame()
    df1.to_excel(writer1, sheet_name="Summary_GSTR1", index=False)

    writer1.save()

    fullpath2 = fullpath1a

    wb = load_workbook(fullpath2)
    ws = wb["Summary_GSTR1"]

    ws["A1"].value = "AUTOMATION SOLUTIONS BY EFFICIENT CORPORATES-[TM]"
    ws["A4"].value = "Summary of the GSTR-1 File Compiled"

    ws["A6"].value = "GSTIN of the Seller"
    ws["A7"].value = "GSTR-1 filing period"
    ws["A8"].value = "GSTR-1 filing Type"
    ws["A9"].value = "GT"

    ws["A10"].value = "CUR_GT"
    ws["A11"].value = "FILING DATE"

    ws["A15"].value = "SUMMARY OF THE DIFFERENT TABLES IN THE GSTR-1 FILE"

    ws.merge_cells("A15:I15")

    ws["A17"].value = "GSTR-1 Tables"
    ws["B17"].value = "Count"
    ws["C17"].value = "Invoice Amount"
    ws["D17"].value = "Taxable Value"
    ws["E17"].value = "IGST"
    ws["F17"].value = "CGST"

    ws["G17"].value = "SGST"
    ws["H17"].value = "Cess"
    ws["I17"].value = "Total Tax Amount"

    ws["A18"].value = "BUSINESS-2- BUSINESS (B2B)"
    ws["A19"].value = "BUSINESS-2- CONSUMER-SMALL (B2CS)"

    ws["A20"].value = "BUSINESS-2- CONSUMER-LARGE (B2CL)"
    ws["A21"].value = "EXPORT (EXP)"
    ws["A22"].value = "CREDIT NOTE / DEBIT NOTE (CDNR)"

    ws["A24"].value = "HSN SUMMARY"

    with open(filepath) as json_file:
        data = json.load(json_file)

    dic_keys = data.keys

    df_all_combined = pd.DataFrame()

    for i in dic_keys():

        if i == "gstin":
            gst = data[i]
            ws["B6"].value = gst

        elif i == "fp":
            fp = data[i]
            ws["B7"].value = fp

        elif i == "filing_typ":
            fil = data[i]
            if fil == "M":
                ws["B8"].value = "Monthly"
            elif fil == "Q":
                ws["B8"].value = "Quarterly"
            else:
                ws["B8"].value = fil

        elif i == "gt":
            gt = data[i]
            ws["B9"].value = gt

        elif i == "cur_gt":
            cur_gt = data[i]
            ws["B10"].value = cur_gt

        elif i == "b2b":

            b2b_data = data[i]
            dic_b2b = expand_list(b2b_data)

            try:
                df_b2b = pd.DataFrame(dic_b2b)
            except ValueError:
                df_b2b = pd.DataFrame(dic_b2b, index=[0])

            df_b2b["GSTR1-Table"] = "B2B"
            df_b2b["Json File Name"] = filepath

            df_b2b.to_excel(writer, sheet_name='B2B_DATA', index=False)

            df_all_combined = df_all_combined.append(df_b2b)


        elif i == "b2cl":
            b2cl_data = data[i]
            dic_b2cl = expand_list(b2cl_data)

            try:
                df_b2cl = pd.DataFrame(dic_b2cl)
            except ValueError:
                df_b2cl = pd.DataFrame(dic_b2cl, index=[0])

            df_b2cl["GSTR1-Table"] = "B2C-L"
            df_b2cl["Json File Name"] = filepath

            df_b2cl.to_excel(writer, sheet_name='B2CL_DATA', index=False)

            df_all_combined = df_all_combined.append(df_b2cl)

        elif i == "cdnr":

            cdnr_data = data[i]
            dic_cdnr = expand_list(cdnr_data)

            try:
                df_cdnr = pd.DataFrame(dic_cdnr)
            except ValueError:
                df_cdnr = pd.DataFrame(dic_cdnr, index=[0])
            df_cdnr["GSTR1-Table"] = "CDNR"
            df_cdnr["Json File Name"] = filepath

            df_cdnr.to_excel(writer, sheet_name='CDNR_DATA', index=False)

            df_cdnr.rename(columns={"inv_typ": "Note_Supply_Type",
                                    "ntty": "Final_Inv_CNDN_Type"}, inplace=True)

            df_all_combined = df_all_combined.append(df_cdnr)


        elif i == "exp":
            exp_data = data[i]
            dic_exp = expand_list(exp_data)

            try:
                df_exp = pd.DataFrame(dic_exp)
            except ValueError:
                df_exp = pd.DataFrame(dic_exp, index=[0])
            df_exp["GSTR1-Table"] = "EXPORT"
            df_exp["Json File Name"] = filepath

            df_exp.to_excel(writer, sheet_name='EXPORT_DATA', index=False)

            df_all_combined = df_all_combined.append(df_exp)

        elif i == "b2cs":
            b2cs_data = data[i]
            dic_b2cs = expand_list(b2cs_data)

            try:
                df_b2cs = pd.DataFrame(dic_b2cs)
            except ValueError:
                df_b2cs = pd.DataFrame(dic_b2cs, index=[0])
            df_b2cs["GSTR1-Table"] = "B2C-S"
            df_b2cs["Json File Name"] = filepath

            df_b2cs.to_excel(writer, sheet_name='B2CS_DATA', index=False)

            df_all_combined = df_all_combined.append(df_b2cs)

        elif i == "hsn":
            hsn_data = data[i]
            dic_hsn = flatten_dict(hsn_data)

            try:
                df_hsn = pd.DataFrame(dic_hsn)
            except ValueError:
                df_hsn = pd.DataFrame(dic_hsn, index=[0])
            df_hsn.to_excel(writer, sheet_name='HSN_DATA', index=False)

        elif i == "nil":
            nil_data = data[i]
            dic_nil = flatten_dict(nil_data)

            try:
                df_nil = pd.DataFrame(dic_nil)
            except ValueError:
                df_nil = pd.DataFrame(dic_nil, index=[0])
            df_nil.to_excel(writer, sheet_name='NIL_NONGST_DATA', index=False)

        elif i == "doc_issue":
            doc_data = data[i]
            dic_doc = flatten_dict(doc_data)

            try:
                df_doc = pd.DataFrame(dic_doc)
            except ValueError:
                df_doc = pd.DataFrame(dic_doc, index=[0])

            df_doc.to_excel(writer, sheet_name='DOC_SERIES_DATA', index=False)

        elif i == "fil_dt":
            fildt = data["fil_dt"]
            ws["B11"].value = fildt

        else:
            add_case = data[i]

            if isinstance(add_case, list):
                dic_add_case = expand_list(add_case)

                try:
                    df_add_case = pd.DataFrame(dic_add_case)
                except ValueError:
                    df_add_case = pd.DataFrame(dic_add_case, index=[0])

                df_add_case["GSTR1-Table"] = i
                df_add_case.to_excel(writer, sheet_name=i, index=False)

            elif isinstance(add_case, dict):
                dic_add_case = flatten_dict(add_case)

                try:
                    df_add_case = pd.DataFrame(dic_add_case)
                except ValueError:
                    df_add_case = pd.DataFrame(dic_add_case, index=[0])

                df_add_case["GSTR1-Table"] = i
                df_add_case.to_excel(writer, sheet_name=i, index=False)
            else:
                pass

    rename_r1_columns(df_all_combined)
    df_all_combined.to_excel(writer, sheet_name="effcorp_all_combined", index=False)

    wb.save(fullpath2)
    writer.save()

    try:
        ws["B18"].value = len(df_b2b["ctin"])
        ws["C18"].value = df_b2b["val"].sum()
        ws["D18"].value = df_b2b["txval"].sum()
        ws["E18"].value = df_b2b["iamt"].sum()
        ws["F18"].value = df_b2b["camt"].sum()
        ws["G18"].value = df_b2b["samt"].sum()
        ws["H18"].value = df_b2b["csamt"].sum()
        ws["I18"].value = df_b2b["iamt"].sum() + df_b2b["camt"].sum() + df_b2b["samt"].sum() + df_b2b["csamt"].sum()
    except:
        pass

    try:

        ws["B19"].value = len(df_b2cs["rt"])
        #     ws["C19"].value = sum(df_b2cs["val"])
        ws["D19"].value = df_b2cs["txval"].sum()
        ws["E19"].value = df_b2cs["iamt"].sum()
        ws["F19"].value = df_b2cs["camt"].sum()
        ws["G19"].value = df_b2cs["samt"].sum()
        ws["I19"].value = df_b2cs["iamt"].sum() + df_b2cs["camt"].sum() + df_b2cs["samt"].sum()
    except:
        pass

    try:
        ws["B20"].value = len(df_b2cl["val"])
        ws["C20"].value = df_b2cl["val"].sum()
        ws["D20"].value = df_b2cl["txval"].sum()
        ws["E20"].value = df_b2cl["iamt"].sum()
        ws["H20"].value = df_b2cl["csamt"].sum()
        ws["I20"].value = df_b2cl["iamt"].sum()

    except:
        pass

    try:

        ws["B21"].value = len(df_exp["flag"])
        ws["C21"].value = df_exp["val"].sum()
        ws["D21"].value = df_exp["txval"].sum()
        ws["E21"].value = df_exp["iamt"].sum()
        ws["H21"].value = df_exp["csamt"].sum()
        ws["I21"].value = df_exp["iamt"].sum()
    except:
        pass

    try:

        ws["B22"].value = len(df_cdnr["flag"])
        ws["C22"].value = df_cdnr["val"].sum()
        ws["D22"].value = df_cdnr["txval"].sum()
        ws["E22"].value = df_cdnr["iamt"].sum()
        ws["H22"].value = df_cdnr["csamt"].sum()
        ws["I22"].value = df_cdnr["iamt"].sum()

    except:
        pass

    try:
        ws["B24"].value = len(df_hsn["flag"])
        ws["D24"].value = df_hsn["txval"].sum()
        ws["E24"].value = df_hsn["iamt"].sum()
        ws["F24"].value = df_hsn["camt"].sum()
        ws["G24"].value = df_hsn["samt"].sum()
        ws["H24"].value = df_hsn["csamt"].sum()
        ws["I24"].value = df_hsn["iamt"].sum() + df_hsn["camt"].sum() + df_hsn["samt"].sum() + df_hsn["csamt"].sum()

    except:
        pass

    writer.save()

    wb.save(fullpath2)
    writer.save()

    wb.close()
    writer.close()

    return (fullpath1)
