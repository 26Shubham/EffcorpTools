
from django.urls import path,include
from . import views

urlpatterns = [
    path('gstr2b', views.index,name='gstr2bjson'),
    path('gstr1', views.gstr1json,name='gstr1json'),
    path('gstinvalidator',views.index1,name='index'),
    path('gstr2a',views.gstr2a_merge,name='gstr2a'),
    path('gststatus',views.getstatus,name='getstatus'),
    path('reco',views.reco,name='reco'),
    path('recoutility',views.recoutility,name='utility'),
    path('',views.home,name='home')

    # path('', views.index,name='home')
    # path('type/<id>/_fetch', views.index,name='gstr1json')
    # (r'/(?P<type>\w{0,50})/$', views.profile_page,),


]