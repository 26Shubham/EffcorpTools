from django import forms



class MyfileuploadForm(forms.Form):
    # file_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    files_data = forms.FileField(widget=forms.FileInput(attrs={'class': 'form-control', 'multiple':True}))
    # files_data =forms.FileField(allow_folders=True, path= "/")

# class MyfileuploadForm2(forms.Form):
#     # file_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
#     files_data2 = forms.FileField(widget=forms.FileInput(attrs={'class': 'form-control', 'multiple':True}))