from django.contrib import admin

# Register your models here.
from .models import file_upload

admin.site.register(file_upload)